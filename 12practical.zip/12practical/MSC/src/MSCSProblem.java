import java.util.Random;

public class MSCSProblem {

    static long countMscOn3 = 0;
    static long countMscOn2A = 0;
    static long countMscOn2B = 0;
    static long countMscOnlogn = 0;
    static long countMscOn = 0;

    public static int mcsOn3(int[] X) {
        int n = X.length;
        int maxSoFar = 0;


        for (int low = 0; low < n; low++) {
            for (int high = low; high < n; high++) {
                int sum = 0;
                for (int r = low; r < high; r++) {
                    sum += X[r];
                    countMscOn3++;
                }
                if (sum > maxSoFar) {
                    maxSoFar = sum;

                }
            }
            return maxSoFar;
        }
    }

    public static int mcsOn2A(int[] X) {
        int n = X.length;
        int maxSoFar = 0;

        for (int low = 0; low < n; low++) {
            int sum = 0;
            for (int r = low; r < n; r++) {
                sum += X[r];
                countMscOn2A++;
            }
            if (sum > maxSoFar) {
                maxSoFar = sum;
            }
        }
        return maxSoFar;
    }

    public static int mcsOn2B(int[] X) {
        int n = X.length;
        int[] sumTo = new int[n + 1];

        for (int i = 1; i <= n; i++) {
            sumTo[i] = sumTo[i - 1] + X[i - 1];
        }
        int maxSoFar = 0;

        for (int low = 0; low < n; low++) {
            for (int high = low; high < n; high++) {
                int sum = sumTo[high] - sumTo[low - 1];
                countMscOn2B++;
                if (sum > maxSoFar)
                    maxSoFar = sum;
            }
        }
        return maxSoFar;
    }

    public static int maxStraddle(int[] X, int low, int high) {

        if (low >= high) {
            return 0;
        }
        if (low == high) {
            return Math.max(0, X[low]);
        }
        int middle = (low + high) / 2;
        int sum = 0;
        int maxSoFarLeft = 0;

        for (int i = middle; i >= low; i--) {
            sum += X[i];
            if (sum > maxSoFarLeft) {
                maxSoFarLeft = sum;
            }
        }
        sum = 0;
        int maxSoFarRight = 0;

        for (int i = middle + 1; i <= high; i++) {
            int n = X.length;
            if (i >= n) {
                break;
            }
            sum += X[i];

            if (sum > maxSoFarRight) {
                maxSoFarRight = sum;
            }
        }
        return maxSoFarLeft + maxSoFarRight;
    }

    public static int mcsOnLogn(int[] X, int low, int high) {
        if (low >= high) {
            return 0;
        }
        if (low == high - 1) {
            if (low == X.length) {
                return 0;
            }
            return Math.max(0, X[low]);
        }
        if (low == high - 2) {
            int sum = 0;
            for (int i = low; i < high; i++) {
                if (X[i] > 0) {
                    sum += X[i];
                    countMscOnlogn++;
                }
            }
            return sum;
        }
        int middle = (low + high) / 2;
        int mLeft = mcsOnLogn(X, low, middle);
        int mRight = mcsOnLogn(X, middle + 1, high);
        int mStraddle = maxStraddle(X, low, high);

    return Math.max(Math.max(mLeft, mRight), mStraddle);
    }

    public static double mscOn(double[] X) {
        int N = X.length;
        double maxSoFar = 0.0;
        double maxToHere = 0.0;

        for (int i = 0; i < N; i++) {
            maxToHere = Math.max(maxToHere + X[i], 0.0);
            maxSoFar = Math.max(maxSoFar, maxToHere);

        }
        return maxSoFar;
    }

    public static int[] createArray(int n) {
        Random rand = new Random();
        int[] X = new int[n];

        for (int k = 0; k < n; k++) {
            int value = rand.nextInt(n) + 1;
            if (rand.nextInt(3) == 0)
                value = -value;
                X[k] = value;

        }
        return X;
    }

          public static void main(String []args){
        int []sizes = {100,1000,10000,10000};
              System.out.println("%10s %15s %15s %15s %15/n","n","O(n^3)","O(n^2)A","O(n^2)B","O(nlogn)","O(n)",);
              for (int n : sizes){
                  int[] X = createArray(n);

                  countMscOn3 = 0;
                  countMscOn2A = 0;
                  countMscOn2B=0;
                  countMscOnlogn=0;
                  countMscOn = 0;

                  if (n <=10000)
                      mcsOn3(X);
                  if (n <=100000)
                      mcsOn2A(X);
                  if (n <=100000)
                      mcsOn2B(X);
                  if (n <=100000)
                      mcsOnLogn(X);
                  mscOn(X);
                  System.out.println("%10d %15d %15d %15d %15/n",n,countMscOn3,countMscOn2A,countMscOn2B,countMscOnlogn,countMscOn);

              }

    }
}
